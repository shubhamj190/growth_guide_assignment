# Growth Guide assignment

To run this project please use the following steps:
- Clone the repo locally
- Create an virtual environment of your respective OS
- Run the command ```pip install -r requirements.txt```
- Run migrations commands ```python manage.py makemigrations``` and ```python manage.py migrate```
- Last run the development server ```python manage.py runserver```
